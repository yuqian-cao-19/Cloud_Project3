document.addEventListener("DOMContentLoaded", async function () {
  let tabsContainer = document.getElementById("tabs-container");
  tabsContainer.innerHTML = "";

  chrome.windows.getAll({ populate: true }, async (windows) => {
    for (const window of windows) {
      for (const tab of window.tabs) {
        let tabElement = document.createElement("div");
        tabElement.innerHTML = `
        <span class="tab-title">${tab.title}</span>
      `;
        tabElement.className = "tab";
        tabsContainer.appendChild(tabElement);
      }
    }
  });
});
